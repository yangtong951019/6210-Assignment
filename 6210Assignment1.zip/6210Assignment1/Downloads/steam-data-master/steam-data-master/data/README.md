# Steam Data Setup

This subdir is for gathering the data we need using freely available API's
with Python.

You should have Python 3 and `make` installed to use the `Makefile`

Please be careful with `make clean` - it will delete the Python virtual env
and all previous data, so be sure that's what you want.
